#!/bin/bash

# /persistent/docker/volumes/sensorlog/_data
docker volume create sensorlog
